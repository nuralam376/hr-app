module.exports = {
  accessKeyId: " AKIAYBBL3Q465JO4XDWW",
  secretAccessKey: "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",
};
